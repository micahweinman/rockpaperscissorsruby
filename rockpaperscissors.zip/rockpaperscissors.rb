require './rpsgame_start.rb'
RPSGame.start
