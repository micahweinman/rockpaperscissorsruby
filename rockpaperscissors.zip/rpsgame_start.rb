class RPSGame

  def self.rock(userchoice, computerchoice)
    if userchoice == "r" && computerchoice == "p"
      puts "You lose!\n\n"
      puts "You won: #{$wins} times.\n\n"
    elsif userchoice == "r" && computerchoice == "s"
      puts "You win!\n\n"
      $wins += 1
      puts "You won: #{$wins} times.\n\n"
    elsif userchoice == computerchoice
      puts "Tie!\n\n"
      puts "You won: #{$wins} times.\n\n"
    else
      puts "That is not a valid input. \n\nPress 'r' for Rock, 'p' for Paper, 's' for Scissors, 'x' to display the score, or 'q' to quit the game.\n\n"
    end
  end

  def self.scissors(userchoice, computerchoice)
    if userchoice == "s" && computerchoice == "r"
      puts "You lose!\n\n"
      puts "You won: #{$wins} times.\n\n"
    elsif userchoice == "s" && computerchoice == "p"
      puts "You win!\n\n"
      $wins += 1
      puts "You won: #{$wins} times.\n\n"
    elsif userchoice == computerchoice
      puts "Tie!\n\n"
      puts "You won: #{$wins} times.\n\n"
    else
      puts "That is not a valid input. \n\nPress 'r' for Rock, 'p' for Paper, 's' for Scissors, 'x' to display the score, or 'q' to quit the game.\n\n"
    end
  end

  def self.paper(userchoice, computerchoice)
    if userchoice == "p" && computerchoice == "s"
      puts "You lose!\n\n"
      puts "You won: #{$wins} times.\n\n"
    elsif userchoice == "p" && computerchoice == "r"
      puts "You win!\n\n"
      $wins += 1
      puts "You won: #{$wins} times.\n\n"
    elsif userchoice == computerchoice
      puts "Tie!\n\n"
      puts "You won: #{$wins} times.\n\n"
    else
      puts "That is not a valid input. \n\nPress 'r' for Rock, 'p' for Paper, 's' for Scissors, 'x' to display the score, or 'q' to quit the game.\n\n"
    end
  end

  def RPSGame.start
    $wins = 0
    choices = ["r", "p", "s"]
    flag = true
    puts "Hello, welcome to the game of Rock, Paper, Scissors.\n\n"
    while(flag == true)
    puts "Are you ready to play? \n\nPress 'r' for Rock, 'p' for Paper, 's' for Scissors, \n'x' to display the score, or 'q' to quit.\n\n"
    userchoice = $stdin.gets.chomp
    computerchoice = choices.sample
    if userchoice == "r"
      puts computerchoice
      puts "\n"
      rock(userchoice, computerchoice)
    elsif userchoice == "p"
      puts computerchoice
      puts "\n"
      paper(userchoice, computerchoice)
    elsif userchoice == "s"
      puts computerchoice
      puts "\n"
      scissors(userchoice, computerchoice)
    elsif userchoice == "x"
      puts "\nYou won: #{$wins} times.\n\n"
    elsif userchoice == "q"
      puts "\nThank you for playing!\n\n"
      puts "You won: #{$wins} times."
      flag = false
    elsif userchoice == "cheat"
      while userchoice != "off"
      puts "Are you ready to play? \n\nPress 'r' for Rock, 'p' for Paper, 's' for Scissors, \n'x' to display the score, or 'q' to quit.\n\n"
      userchoice = $stdin.gets.chomp
      if userchoice == "r"
        puts "p"
        puts "You lose!\n\n"
        puts "You won: #{$wins} times.\n\n"
      elsif userchoice == "s"
        puts "r"
        puts "You lose!\n\n"
        puts "You won: #{$wins} times.\n\n"
      elsif userchoice == "p"
        puts "s"
        puts "You lose!\n\n"
        puts "You won: #{$wins} times.\n\n"
      elsif userchoice == "x"
        puts "\nYou won: #{$wins} times.\n\n"
      elsif userchoice == "q"
        puts "\nThank you for playing!\n\n"
        puts "You won: #{$wins} times."
        exit(0)
      else
        puts "That is not a valid input. \n\nPress 'r' for Rock, 'p' for Paper, 's' for Scissors, 'x' to display the score, or 'q' to quit the game.\n\n"
      end
    end
    else
      puts "\nThat is not a valid input. \n\nPress 'r' for Rock, 'p' for Paper, 's' for Scissors, 'x' to display the score, or 'q' to quit the game.\n\n"
    end

    end
  end
end
